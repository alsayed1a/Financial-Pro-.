import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FinancialDb.instance.database;
  runApp(const FinancialProApp());
}

const navy = Color(0xFF14243A);
const blue = Color(0xFF2463EB);
const bg = Color(0xFFF3F6FB);
final moneyFormat = NumberFormat('#,##0.##', 'en');

String money(num value) => '${moneyFormat.format(value)} ج.م';

class FinancialProApp extends StatelessWidget {
  const FinancialProApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Financial Pro',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: blue),
      scaffoldBackgroundColor: bg,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    ),
    home: const Directionality(textDirection: TextDirection.rtl, child: HomePage()),
  );
}

class FinancialEntry {
  final int? id;
  final String type;
  final String description;
  final double amount;
  final String date;
  final String category;
  const FinancialEntry({this.id, required this.type, required this.description, required this.amount, required this.date, required this.category});
  Map<String, Object?> toMap() => {'id': id, 'type': type, 'description': description, 'amount': amount, 'date': date, 'category': category};
  factory FinancialEntry.fromMap(Map<String, Object?> m) => FinancialEntry(
    id: m['id'] as int, type: m['type'] as String, description: m['description'] as String,
    amount: (m['amount'] as num).toDouble(), date: m['date'] as String, category: m['category'] as String);
}

class FinancialDb {
  FinancialDb._();
  static final instance = FinancialDb._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(p.join(dir, 'financial_pro.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE entries(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          type TEXT NOT NULL CHECK(type IN ('income','expense')),
          description TEXT NOT NULL,
          amount REAL NOT NULL CHECK(amount > 0),
          date TEXT NOT NULL,
          category TEXT NOT NULL
        )''');
        await db.execute('CREATE INDEX idx_entries_date ON entries(date)');
        await db.execute('CREATE INDEX idx_entries_type ON entries(type)');
      });
    return _db!;
  }
  Future<List<FinancialEntry>> all() async {
    final rows = await (await database).query('entries', orderBy: 'date DESC, id DESC');
    return rows.map(FinancialEntry.fromMap).toList();
  }
  Future<void> insert(FinancialEntry e) async => (await database).insert('entries', e.toMap());
  Future<void> delete(int id) async => (await database).delete('entries', where: 'id=?', whereArgs: [id]);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  List<FinancialEntry> entries = [];
  bool loading = true;
  @override void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    final data = await FinancialDb.instance.all();
    if (mounted) setState(() { entries = data; loading = false; });
  }
  double get income => entries.where((e)=>e.type=='income').fold(0, (s,e)=>s+e.amount);
  double get expenses => entries.where((e)=>e.type=='expense').fold(0, (s,e)=>s+e.amount);
  double get net => income-expenses;
  void go(int i) => setState(()=>tab=i);
  @override Widget build(BuildContext context) {
    final pages = [
      dashboard(), transactionsPage(), analysisPage(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Financial Pro', style: TextStyle(fontWeight: FontWeight.bold)), centerTitle: false,
        actions: [IconButton(onPressed: exportCsv, icon: const Icon(Icons.file_download_outlined), tooltip: 'تصدير CSV')]),
      body: loading ? const Center(child:CircularProgressIndicator()) : RefreshIndicator(onRefresh:refresh, child: pages[tab]),
      floatingActionButton: tab==1 ? FloatingActionButton.extended(onPressed:addEntry, backgroundColor:blue, foregroundColor:Colors.white, icon:const Icon(Icons.add), label:const Text('إضافة عملية')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex:tab, onDestinationSelected:go, destinations: const [
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'الرئيسية'),
        NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'العمليات'),
        NavigationDestination(icon:Icon(Icons.analytics_outlined),selectedIcon:Icon(Icons.analytics),label:'التحليل'),
      ]),
    );
  }
  Widget dashboard() => ListView(padding:const EdgeInsets.all(16), children:[
    const Text('ملخص الأداء المالي',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
    const SizedBox(height:4), Text(DateFormat('EEEE، d MMMM y','ar').format(DateTime.now()),style:TextStyle(color:Colors.grey[600])),
    const SizedBox(height:16),
    GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,childAspectRatio:1.55,crossAxisSpacing:10,mainAxisSpacing:10,children:[
      metric('إجمالي الإيرادات',income,Icons.trending_up,const Color(0xFF15966A)),
      metric('إجمالي المصروفات',expenses,Icons.trending_down,const Color(0xFFDC4C55)),
      metric('صافي الربح / الخسارة',net,Icons.account_balance_wallet,net>=0?const Color(0xFF15966A):const Color(0xFFDC4C55)),
      metric('هامش صافي الربح',income==0?0:net/income*100,Icons.percent,blue, suffix:'%'),
    ]),
    const SizedBox(height:14),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('الإيرادات مقابل المصروفات',style:TextStyle(fontWeight:FontWeight.bold,fontSize:16)),
      const SizedBox(height:16),
      barLine('الإيرادات',income, income+expenses,const Color(0xFF15966A)),
      const SizedBox(height:14),barLine('المصروفات',expenses,income+expenses,const Color(0xFFDC4C55)),
      const SizedBox(height:10),Text('صافي النتيجة: ${money(net)}',style:const TextStyle(fontWeight:FontWeight.bold)),
    ]))),
    const SizedBox(height:14),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('آخر العمليات',style:TextStyle(fontWeight:FontWeight.bold,fontSize:16)),
      const SizedBox(height:8),
      if(entries.isEmpty) const Text('لا توجد عمليات بعد. افتح قسم العمليات لإضافة أول عملية.',style:TextStyle(color:Colors.grey))
      else ...entries.take(4).map(entryTile),
    ]))),
    const SizedBox(height:80),
  ]);
  Widget metric(String title,double value,IconData icon,Color color,{String suffix=' ج.م'}) => Card(child:Padding(padding:const EdgeInsets.all(13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
    Icon(icon,color:color,size:22),Text(title,style:TextStyle(color:Colors.grey[700],fontSize:12)),
    FittedBox(fit:BoxFit.scaleDown,child:Text('${moneyFormat.format(value)}$suffix',style:TextStyle(fontWeight:FontWeight.bold,fontSize:18,color:color))),
  ])));
  Widget barLine(String title,double value,double total,Color color) {
    final pct=total==0?0.0:value/total;
    return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(title),Text('${(pct*100).toStringAsFixed(1)}%')]),
      const SizedBox(height:7),ClipRRect(borderRadius:BorderRadius.circular(20),child:LinearProgressIndicator(value:pct,minHeight:10,backgroundColor:bg,color:color)),
    ]);
  }
  Widget transactionsPage() => ListView(padding:const EdgeInsets.all(16),children:[
    Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('العمليات المالية',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),Text('${entries.length} عملية',style:TextStyle(color:Colors.grey[600]))]),
    const SizedBox(height:12),
    if(entries.isEmpty) Card(child:Padding(padding:const EdgeInsets.all(25),child:Column(children:[const Icon(Icons.receipt_long,size:42,color:Colors.grey),const SizedBox(height:8),const Text('لا توجد بيانات مسجلة'),const SizedBox(height:6),Text('اضغط «إضافة عملية» لتسجيل إيراد أو مصروف.',style:TextStyle(color:Colors.grey[600]))])))
    else ...entries.map(entryTile),
    const SizedBox(height:80),
  ]);
  Widget entryTile(FinancialEntry e) => Card(margin:const EdgeInsets.only(bottom:8),child:ListTile(
    leading:CircleAvatar(backgroundColor:(e.type=='income'?const Color(0xFFE4F6EF):const Color(0xFFFFEEEE)),child:Icon(e.type=='income'?Icons.south_west:Icons.north_east,color:e.type=='income'?const Color(0xFF15966A):const Color(0xFFDC4C55))),
    title:Text(e.description,style:const TextStyle(fontWeight:FontWeight.w600)),
    subtitle:Text('${e.category} • ${e.date}'),
    trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[
      Text('${e.type=='income'?'+':'−'} ${money(e.amount)}',style:TextStyle(fontWeight:FontWeight.bold,color:e.type=='income'?const Color(0xFF15966A):const Color(0xFFDC4C55),fontSize:12)),
      InkWell(onTap:()=>removeEntry(e),child:const Padding(padding:EdgeInsets.only(top:5),child:Text('حذف',style:TextStyle(color:Colors.red,fontSize:11)))),
    ]),
  ));
  Widget analysisPage() {
    final months=<String,double>{};
    for(final e in entries){final key=e.date.substring(0,7);months[key]=(months[key]??0)+(e.type=='income'?e.amount:-e.amount);}
    final sorted=months.keys.toList()..sort();
    final spots=<FlSpot>[];
    for(var i=0;i<sorted.length;i++){spots.add(FlSpot(i.toDouble(),months[sorted[i]]!));}
    final margin=income==0?0:net/income*100;
    return ListView(padding:const EdgeInsets.all(16),children:[
      const Text('التحليل المالي',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('صافي النتيجة حسب الشهر',style:TextStyle(fontWeight:FontWeight.bold)),
        const SizedBox(height:18),
        if(spots.isEmpty) const SizedBox(height:100,child:Center(child:Text('أضف بيانات لعرض الرسم البياني',style:TextStyle(color:Colors.grey))))
        else SizedBox(height:210,child:LineChart(LineChartData(
          gridData:const FlGridData(show:true),borderData:FlBorderData(show:false),
          titlesData:FlTitlesData(topTitles:const AxisTitles(sideTitles:SideTitles(showTitles:false)),rightTitles:const AxisTitles(sideTitles:SideTitles(showTitles:false)),
            bottomTitles:AxisTitles(sideTitles:SideTitles(showTitles:true,reservedSize:30,getTitlesWidget:(v,m)=>Padding(padding:const EdgeInsets.only(top:8),child:Text(v.toInt()>=0&&v.toInt()<sorted.length?sorted[v.toInt()]:'' ,style:const TextStyle(fontSize:9)))))),
          lineBarsData:[LineChartBarData(spots:spots,isCurved:true,color:blue,barWidth:3,dotData:const FlDotData(show:true),belowBarData:BarAreaData(show:true,color:blue.withOpacity(.10)))]
        ))),
      ]))),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('المؤشرات المالية',style:TextStyle(fontWeight:FontWeight.bold,fontSize:16)),
        const SizedBox(height:12),indicator('صافي الربح / الخسارة',money(net)),
        indicator('هامش صافي الربح','${margin.toStringAsFixed(2)}%'),
        indicator('نسبة المصروفات إلى الإيرادات',income==0?'غير متاح':'${(expenses/income*100).toStringAsFixed(2)}%'),
        indicator('عدد العمليات',entries.length.toString()),
      ]))),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('ملاحظات تفسيرية',style:TextStyle(fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        Text(income==0?'لا توجد إيرادات مسجلة حتى الآن.':net>=0?'صافي النتيجة موجب خلال البيانات المسجلة. قارن الفترات لمعرفة اتجاه الأداء.':'المصروفات تتجاوز الإيرادات في البيانات المسجلة؛ راجع بنود التكلفة والإيراد.',style:TextStyle(color:Colors.grey[700],height:1.6)),
      ]))),
      const SizedBox(height:80),
    ]);
  }
  Widget indicator(String label,String value)=>Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Expanded(child:Text(label,style:TextStyle(color:Colors.grey[700]))),Text(value,style:const TextStyle(fontWeight:FontWeight.bold))]));
  Future<void> addEntry() async {
    final form=GlobalKey<FormState>();final desc=TextEditingController();final amount=TextEditingController();
    String type='income',category='مبيعات';DateTime date=DateTime.now();
    final categories=['مبيعات','خدمات','استثمارات','رواتب','إيجار','تشغيل','مرافق','تسويق','أخرى'];
    final ok=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,backgroundColor:Colors.white,builder:(ctx)=>StatefulBuilder(builder:(ctx,setModal)=>Padding(
      padding:EdgeInsets.only(left:18,right:18,top:22,bottom:MediaQuery.of(ctx).viewInsets.bottom+22),
      child:Form(key:form,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('إضافة عملية مالية',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:16),
        SegmentedButton<String>(segments:const [ButtonSegment(value:'income',label:Text('إيراد'),icon:Icon(Icons.south_west)),ButtonSegment(value:'expense',label:Text('مصروف'),icon:Icon(Icons.north_east))],selected:{type},onSelectionChanged:(s)=>setModal(()=>type=s.first)),
        const SizedBox(height:12),
        TextFormField(controller:desc,decoration:const InputDecoration(labelText:'البيان',border:OutlineInputBorder()),validator:(v)=>v==null||v.trim().isEmpty?'اكتب البيان':null),
        const SizedBox(height:10),
        TextFormField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),inputFormatters:[FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],decoration:const InputDecoration(labelText:'المبلغ بالجنيه المصري',border:OutlineInputBorder()),validator:(v)=>double.tryParse(v??'')==null||double.parse(v!)<=0?'أدخل مبلغًا صحيحًا':null),
        const SizedBox(height:10),
        DropdownButtonFormField<String>(value:category,decoration:const InputDecoration(labelText:'التصنيف',border:OutlineInputBorder()),items:categories.map((c)=>DropdownMenuItem(value:c,child:Text(c))).toList(),onChanged:(v)=>setModal(()=>category=v??'أخرى')),
        const SizedBox(height:10),
        ListTile(contentPadding:EdgeInsets.zero,title:Text('التاريخ: ${DateFormat('yyyy-MM-dd').format(date)}'),trailing:const Icon(Icons.calendar_month),onTap:()async{final d=await showDatePicker(context:ctx,initialDate:date,firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setModal(()=>date=d);}),
        const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:(){if(form.currentState!.validate())Navigator.pop(ctx,true);},child:const Text('حفظ العملية'))),
      ])))
    )));
    if(ok==true){await FinancialDb.instance.insert(FinancialEntry(type:type,description:desc.text.trim(),amount:double.parse(amount.text),date:DateFormat('yyyy-MM-dd').format(date),category:category));await refresh();}
    desc.dispose();amount.dispose();
  }
  Future<void> removeEntry(FinancialEntry e) async {
    final yes=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('حذف العملية'),content:Text('هل تريد حذف «${e.description}»؟'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حذف'))]));
    if(yes==true&&e.id!=null){await FinancialDb.instance.delete(e.id!);await refresh();}
  }
  Future<void> exportCsv() async {
    final rows=<List<dynamic>>[['التاريخ','البيان','النوع','التصنيف','المبلغ'],...entries.map((e)=>[e.date,e.description,e.type=='income'?'إيراد':'مصروف',e.category,e.amount])];
    final csv='\uFEFF${const ListToCsvConverter().convert(rows)}';
    final dir=await getTemporaryDirectory();final file=File(p.join(dir.path,'financial_report.csv'));
    await file.writeAsString(csv,flush:true);
    await Share.shareXFiles([XFile(file.path)],text:'تقرير العمليات المالية');
  }
}
