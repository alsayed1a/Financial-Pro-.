# Database schema

Table: `entries`

| Column | Type | Constraint |
|---|---|---|
| id | INTEGER | Primary key, autoincrement |
| type | TEXT | `income` or `expense` |
| description | TEXT | Required |
| amount | REAL | Greater than zero |
| date | TEXT | ISO date `YYYY-MM-DD` |
| category | TEXT | Required |

Indexes: `date`, `type`.

Key calculations:
- Total income = sum(amount where type = income)
- Total expenses = sum(amount where type = expense)
- Net result = total income - total expenses
- Net profit margin = net result / total income * 100 (when total income > 0)
